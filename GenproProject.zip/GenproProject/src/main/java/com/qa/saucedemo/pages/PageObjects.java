package com.qa.saucedemo.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageObjects {
	
	WebDriver driver;
	
	@FindBy(xpath="//input[@placeholder='Username']")
	private WebElement Username;
	
	@FindBy(xpath="//input[@placeholder='Password']")
	private WebElement Password;
	
	@FindBy(xpath="//input[@value='Login']")
	private WebElement Login;
	
	@FindBy(xpath="(//option[text()='Name (A to Z)'])//parent::select")
	private WebElement Sort;
	
	@FindBy(xpath="//option[text()='Price (low to high)']")
	private WebElement Filter;
	
	@FindBy(xpath="//div[text()='29.99']//following-sibling::button")
	private WebElement Bagpack;
	
	@FindBy(xpath="//div[text()='9.99']//following-sibling::button")
	private WebElement Bikelight;
	
	@FindBy(xpath="(//div[text()='15.99']//following-sibling::button)[1]")
	private WebElement Blackshirt;
	
	@FindBy(xpath="//div[text()='49.99']//following-sibling::button")
	private WebElement Jacket;
	
	@FindBy(xpath="//div[text()='7.99']//following-sibling::button")
	private WebElement Whiteshirt;
	
	@FindBy(xpath="(//div[text()='15.99']//following-sibling::button)[2]")
	private WebElement Redshirt;
	
	@FindBy(xpath="(((//span[text()='Products'])//parent::div//preceding-sibling::div)//child::a)[5]")
	private WebElement Cart;
	
	@FindBy(xpath="(//button[text()='Remove'])[2]")
	private WebElement RemoveBikelight;
	
	@FindBy(xpath="(//button[text()='Remove'])[5]")
	private WebElement RemoveWhiteshirt;
	
	@FindBy(xpath="//button[text()='Checkout']")
	private WebElement Checkout;
	
	@FindBy(xpath="//input[@placeholder='First Name']")
	private WebElement Firstname;
	
	@FindBy(xpath="//input[@placeholder='Last Name']")
	private WebElement Lastname;
	
	@FindBy(xpath="//input[@placeholder='Zip/Postal Code']")
	private WebElement Pincode;
	
	@FindBy(xpath="//input[@id='continue']")
	private WebElement Continue;
	
	@FindBy(xpath="//button[text()='Finish']")
	private WebElement Finish;
	
	@FindBy(xpath="//button[text()='Back Home']")
	private WebElement BackHome;
	
	@FindBy(xpath="//button[text()='Open Menu']")
	private WebElement Menu;
	
	@FindBy(xpath="//a[text()='Logout']")
	private WebElement Logout;
	
	public PageObjects(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	public void setUsername(String username)
	{
	Username.sendKeys(username);
	}
	
	public void setPassword(String password)
	{
	Password.sendKeys(password);
	}
	
	public void ClickLogin()
	{
	Login.click();	
	}
	
	public void ClickSort()
	{
	Sort.click();	
	}
	
	public void ClickFilter()
	{
	Filter.click();	
	}
	
	public void ClickBagpack()
	{
	Bagpack.click();	
	}
	
	public void ClickBikelight()
	{
	Bikelight.click();	
	}
	
	public void ClickBlackshirt()
	{
	Blackshirt.click();	
	}
	
	public void ClickJacket()
	{
	Jacket.click();	
	}
	
	public void ClickWhiteshirt()
	{
	Whiteshirt.click();	
	}
	
	public void ClickRedshirt()
	{
	Redshirt.click();	
	}
	
	public void ClickCart()
	{
	Cart.click();	
	}
	
	public void ClickRmvBkLght()
	{
	RemoveBikelight.click();	
	}
	
	public void ClickRmvWtSrt()
	{
	RemoveWhiteshirt.click();	
	}
	
	public void ClickCheckout()
	{
	Checkout.click();	
	}
	
	public void setFirstname(String firstname)
	{
	Firstname.sendKeys(firstname);
	}
	
	public void setLastname(String lastname)
	{
	Lastname.sendKeys(lastname);
	}
	
	public void setPincode(String pincode)
	{
	Pincode.sendKeys(pincode);
	}
	
	public void ClickContinue()
	{
	Continue.click();	
	}
	
	public void ClickFinish()
	{
	Finish.click();	
	}
	
	public void ClickBackHome()
	{
	BackHome.click();	
	}
	
	public void ClickMenu()
	{
	Menu.click();	
	}
	
	public void ClickLogout()
	{
	Logout.click();	
	}
	
	
	
	
	
	
	
	

}
