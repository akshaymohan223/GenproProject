package com.qa.saucedemo.testscripts;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.qa.saucedemo.pages.PageObjects;
import com.qa.saucedemo.utilities.ExcelUtility;

public class TestClass extends TestBase {
	
	PageObjects pgObj;
	
	@Test(priority=1, description="User login with valid data")
	public void UserLogin() throws IOException, InterruptedException
	{
		pgObj=new PageObjects(driver);
		driver.navigate().refresh();
		String username=ExcelUtility.getCellData(0, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx", 0);
		String password=ExcelUtility.getCellData(0, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx", 0);
		pgObj.setUsername(username);
		Thread.sleep(2000);
		pgObj.setPassword(password);
		Thread.sleep(2000);
		pgObj.ClickLogin();
		Thread.sleep(2000);
		if(driver.getCurrentUrl().contains("inventory")) 
		  { 
			  Assert.assertTrue(true); 
			  }
		  else 
		  {
			  Assert.assertTrue(false);
			  }
		
	}
	
	
	@Test(priority=2, description="User purchase products from the website")
	public void UserPurchase() throws InterruptedException, IOException
	{
		pgObj=new PageObjects(driver);
		pgObj.ClickSort();
		Thread.sleep(2000);
		pgObj.ClickFilter();
		Thread.sleep(2000);
		pgObj.ClickWhiteshirt();
		Thread.sleep(3000);
		pgObj.ClickBikelight();
		Thread.sleep(3000);
		pgObj.ClickBlackshirt();
		Thread.sleep(3000);
		pgObj.ClickRedshirt();
		Thread.sleep(3000);
		pgObj.ClickBagpack();
		Thread.sleep(3000);
		pgObj.ClickJacket();
		Thread.sleep(3000);
		pgObj.ClickCart();
		Thread.sleep(3000);
		if(driver.getCurrentUrl().contains("cart")) 
		  { 
			  Assert.assertTrue(true); 
			  }
		  else 
		  {
			  Assert.assertTrue(false);
			  }
		pgObj.ClickRmvBkLght();
		Thread.sleep(2000);
		pgObj.ClickRmvWtSrt();
		Thread.sleep(2000);
		pgObj.ClickCheckout();
		Thread.sleep(2000);
		if(driver.getCurrentUrl().contains("one")) 
		  { 
			  Assert.assertTrue(true); 
			  }
		  else 
		  {
			  Assert.assertTrue(false);
			  }
		
		Thread.sleep(2000);
		String firstname=ExcelUtility.getCellData(1, 0, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx", 0);
		String lastname=ExcelUtility.getCellData(1, 1, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx", 0);
		String pincode=ExcelUtility.getNumericData(1, 2, System.getProperty("user.dir")+"\\src\\main\\resources\\Excel.xlsx", 0);
		pgObj.setFirstname(firstname);
		Thread.sleep(2000);
		pgObj.setLastname(lastname);
		Thread.sleep(2000);
		pgObj.setPincode(pincode);
		Thread.sleep(2000);
		pgObj.ClickContinue();
		Thread.sleep(2000);
		if(driver.getCurrentUrl().contains("two")) 
		  { 
			  Assert.assertTrue(true); 
			  }
		  else 
		  {
			  Assert.assertTrue(false);
			  }
		
		Thread.sleep(2000);
		pgObj.ClickFinish();
		Thread.sleep(2000);
		if(driver.getCurrentUrl().contains("complete")) 
		  { 
			  Assert.assertTrue(true); 
			  }
		  else 
		  {
			  Assert.assertTrue(false);
			  }
		
		Thread.sleep(2000);
		pgObj.ClickBackHome();
		Thread.sleep(2000);
		if(driver.getCurrentUrl().contains("inventory")) 
		  { 
			  Assert.assertTrue(true); 
			  }
		  else 
		  {
			  Assert.assertTrue(false);
			  }
		
		Thread.sleep(2000);
		pgObj.ClickMenu();
		Thread.sleep(2000);
		pgObj.ClickLogout();
		Thread.sleep(2000);
		String actual=driver.getCurrentUrl();
	    String expected="https://www.saucedemo.com/";
	    Assert.assertEquals(expected, actual);
	}

}
